//: [Previous](@previous)

import Foundation

struct Temperature
{
    static var boilingPoint = 100 //instancia de tipo, lo ponemos con static
    //tambien hay metodos de tipo
    static func hello (){
        print ("hola mi boilingPoint es :\(boilingPoint)")
    }
    var celsius: Double
}
var instanciaTemp1 = Temperature(celsius: 200.0)
Temperature.boilingPoint//esta propiedad es para todo el tipo de dato no para las instanciasç
var instanciaTem2 = Temperature(celsius: 400)//a travez de instancias nunca podremos modificar boiling Point
var instanciaTemp3 = instanciaTem2
instanciaTemp3.celsius = -1000.0
instanciaTem2.celsius
Temperature.boilingPoint = 200//en clase se usan apuntadores,no se copian como aca
//como saca copias ocupa mas espacio 

Temperature.boilingPoint
Temperature.hello()//otra vez no se manda a llamar a travez de la instancia si no del tipo

//structure no tienen herencia

let smallerNumber = Double.minimum(100.0, -1000.0)//metodo de tipo de dat, viene incluido en la libreria,ya lo usamos directamente ya no necesitamos una variable, ya es para todos los double

smallerNumber




//: [Next](@next)
