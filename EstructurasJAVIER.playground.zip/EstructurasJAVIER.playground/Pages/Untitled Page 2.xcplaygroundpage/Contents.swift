//: [Previous](@previous)

import Foundation

struct StepCounter{
    var totalSteps: Int=0{//declara una propiedad pero abre un bloque de codigo
        //se llaman observers o observadores de propiedad
       // con will va a cambia r el valor
        //set es que ya cambio
        //oldvalue mantiene el valor antiguo ç
        //new value mantiene el valor nuevo
        willSet
        {
            print("About to set totalSteps to\(newValue)" )
        }
        didSet
        {
            if(totalSteps > oldValue){
                print("Added \(totalSteps - oldValue) steps")
            }
        }
    }
}
var pasosMarduk = StepCounter()
pasosMarduk.totalSteps
pasosMarduk.totalSteps = 10
pasosMarduk.totalSteps
pasosMarduk.totalSteps = 35
pasosMarduk.totalSteps



//: [Next](@next)

