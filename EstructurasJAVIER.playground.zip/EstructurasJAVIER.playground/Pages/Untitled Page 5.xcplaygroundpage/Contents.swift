//: [Previous](@previous)

import Foundation

struct Temperatura {
    var celsius: Double
    var fahrenheit: Double
    var kelvin: Double
    

//var instancia Temp = Temperatura()pide los 3
init (celsius: Double){
    self.celsius = celsius
    fahrenheit = celsius * 1.8 + 32
    kelvin = celsius + 273
}
init (fahrenhit:Double){
    self.fahrenheit = fahrenheit
    kelvin = celsius + 273.15
    celsius = (fahrenhit -32) / 1.8
    
    
    }
    init(kelvin:Double){
        self.kelvin = kelvin
        
    }
}
//: [Next](@next)
