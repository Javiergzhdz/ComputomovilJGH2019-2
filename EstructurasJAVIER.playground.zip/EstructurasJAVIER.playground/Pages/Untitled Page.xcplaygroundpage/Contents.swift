import UIKit

struct Temperatura
{
    var celsius:Double
    var fahrenheit: Double
    {
        return celsius * 1.8 + 32
    }
    /*init (celsius:Double)
    {
        self.celsius = celsius //self le dice que es el de afuerax
     
        
    } *///crea un constructor, si no lo ponemos Swift lo crea solo
    //inicializar todos los parametros de las estructuras que no esten inicializadas
}
var instanciaTemperatura = Temperatura(celsius: 100.0)
instanciaTemperatura.fahrenheit
instanciaTemperatura.celsius = 0
instanciaTemperatura.fahrenheit
//instanciaTemperatura.fahrenheit=200.0 //ESTO YA NO SE PUEDE PORQUE YA ESTA DIRECTAMENTE RELACIONADA CON CELSIUS
