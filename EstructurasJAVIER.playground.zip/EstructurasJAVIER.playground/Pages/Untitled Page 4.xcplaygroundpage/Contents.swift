//: [Previous](@previous)

import Foundation

struct odometer {
    var count: Int=0
     mutating func increment(){
        count += 1
    }
}
var instanciaOdometro = odometer(count:10)
instanciaOdometro.count
for _ in 1 ... 10 {
    instanciaOdometro.increment()
    print (instanciaOdometro.count)
}

//: [Next](@next)
